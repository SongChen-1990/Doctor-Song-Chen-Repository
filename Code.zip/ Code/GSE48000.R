## =================== 0. 环境初始化 ===================
rm(list = ls())                                       
setwd("/data/nas1/refinement12/shifuquan/111")  
if (!dir.exists("./data")) dir.create("./data")   
setwd("./data")                                  

## 加载必备包 
library(GEOquery)   
library(tidyverse)  
library(Biobase)    
library(dplyr)

## =================== 1. 下载 GEO 数据 ===================
GEO_data      <- "GSE48000"     
gene_annotation <- "GPL10558"     

## 1.1 获取 Series Matrix 文件（含表达矩阵 + 样本表型） 
gset <- getGEO(GEO = GEO_data,
               destdir = ".",      
               GSEMatrix = TRUE,   
               getGPL = FALSE)     

## 1.2 提取表达矩阵（probe × sample） 
exp <- exprs(gset[[1]]) %>% as.data.frame()

## =================== 2. 表达矩阵标准化检查 ===================
## 2.1 计算全矩阵分位数，用于判断是否需要 log2 转换 
qx <- as.numeric(quantile(exp,
                          probs = c(0, 0.25, 0.5, 0.75, 0.99, 1.0),
                          na.rm = TRUE))

## 2.2 经验规则：若 99% 分位数 >100 或动态范围 >50 且最小值 >0，则认为未 log 
LogC <- (qx[5] > 100) ||
  (qx[6] - qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)

if (LogC) {
  exp[exp <= 0] <- 0       
  exp <- log2(exp + 1)      
  message("[INFO] log2 transform finished.")} else {
    message("[INFO] log2 transform not needed.")}

## =================== 3. 样本分组 ===================
## 3.1 提取样本临床信息
phe <- pData(gset[[1]]) %>% as.data.frame()

## 3.2 从title列提取分组信息，将三个亚型合并为VTE组
group <- phe %>% 
  dplyr::select(sample = geo_accession, title) %>%
  mutate(group = case_when(
    grepl("Healthy Control", title) ~ "Control",          
    grepl("High Risk|Moderate Risk|Low Risk", title) ~ "VTE", 
    TRUE ~ NA_character_)) %>% na.omit()

## 3.3 查看分组统计
print(table(group$group))

## 3.4 转换为因子，Control为参考水平
group$group <- factor(group$group, levels = c("Control", "VTE"))

## 3.5 按分组排序
group <- group[order(group$group), ]
rownames(group) <- group$sample

## 3.6 保存分组信息
write.csv(group, paste0("group_", GEO_data, ".csv"), 
          quote = FALSE, row.names = FALSE)

## =================== 4. probe → gene 转换 ===================
## 4.1 下载平台注释
gpl <- getGEO(gene_annotation, destdir = ".")
gpl_table <- Table(gpl)

## 4.2 提取探针与基因对应关系
ann <- gpl_table[, c(1, 13)]
colnames(ann) <- c("ID", "symbol")

## 4.3 过滤：去除空值、质控探针、非人类基因
ann <- ann %>%
  filter(symbol != "") %>%
  distinct(ID, .keep_all = TRUE) %>%
  mutate(symbol = str_split_i(symbol, " /// ", 1)) %>%
  filter(!grepl("^phage_|^permuted_|^thrB|^negative", 
                symbol, ignore.case = TRUE)) %>%
  filter(grepl("^[A-Z]", symbol))

## 4.4 表达矩阵转换
exp_filter <- exp[, rownames(group)]
exp_gene <- exp_filter %>%
  as.data.frame() %>%
  rownames_to_column("ID") %>%
  inner_join(ann, by = "ID") %>%
  dplyr::select(-ID) %>%
  group_by(symbol) %>%
  summarise(across(everything(), mean)) %>%
  column_to_rownames("symbol")

## 4.5 保存
write.csv(exp_gene, paste0("expression_", GEO_data, ".csv"), quote = FALSE)



# ==================== 差异表达分析 =====================
rm(list = ls())                                       
setwd("/data/nas1/refinement12/shifuquan/111")  
if (!dir.exists("./DEG")) dir.create("./DEG")   
setwd("./DEG")   

library(ggplot2)
library(ggrepel)
library(viridis)
library(cowplot)
library(ggpubr)
library(limma)
library(ComplexHeatmap)


## ① 读入表达矩阵与分组信息 -----------------------
dat     <- read.csv("../data/expression_GSE48000.csv",
                    row.names = 1, check.names = FALSE)
group   <- read.csv("../data/group_GSE48000.csv", check.names = FALSE)
expr      <- as.matrix(dat)                
condition <- data.frame(Group = group$group, row.names = group$sample)

## ② 设置参数 -------------------------------
group_order <- c("VTE", "Control")
logfc       <- 0.5
p_cut       <- 0.05

## ③ 差异分析 -------------------------------
design <- model.matrix(~0 + condition$Group)
colnames(design) <- group_order
fit    <- lmFit(expr, design)
cont   <- makeContrasts(VTE - Control, levels = design)
fit2   <- contrasts.fit(fit, cont) %>% eBayes()
Res    <- topTable(fit2, n = Inf, adjust = "fdr") %>% na.omit()

## ④ 显著基因筛选 ----------------
Res$sig[Res$P.Value > p_cut | abs(Res$logFC) < logfc] <- "Not"
Res$sig[Res$P.Value < p_cut & Res$logFC > logfc]      <- "Up"
Res$sig[Res$P.Value < p_cut & Res$logFC <= -logfc]    <- "Down"

## ⑤ 输出结果 ----------------------------
print(table(Res$sig))
write.csv(Res, "GSE48000_DEG_all.csv", quote = F)   
dif <- Res[Res$sig != 'Not', ]
write.csv(dif, "GSE48000_DEGs_sig.csv", quote = F)             

## ⑥ Top10 上下调 -------------------------
DEG <- Res
DEG$Symbols <- rownames(DEG)
up_DEG   <- DEG[which(DEG$sig == "Up"),]   %>% arrange(desc(logFC), P.Value)
down_DEG <- DEG[which(DEG$sig == "Down"),] %>% arrange(logFC, P.Value)
data_repel <- rbind(up_DEG[1:10,], down_DEG[1:10,])

## ⑦ 火山图 -------------------------------
DEG$sig <- factor(DEG$sig, levels = c("Up", "Not", "Down"))
max_lfc <- max(DEG$logFC); min_lfc <- min(DEG$logFC);
max_P.Value <- round(max(-log10(DEG$P.Value)))

DEG$lable <- DEG$Symbols
DEG$lable[which(!(DEG$lable %in% rownames(data_repel)))] <- NA

change_colors <- c("orange", "#7b7c7d", "#1177b0")
names(change_colors) <- c("Up", "Not", "Down")

p <- ggplot(data = DEG, aes(x = logFC, y = -log10(P.Value))) +
  geom_point(aes(color = sig), alpha = 1, size = 1.5, shape = 19) +
  geom_text_repel(aes(label = lable), colour = "black", fontface = 'bold',
                  size = 2, max.overlaps = 5000, position = 'identity') +
  scale_color_manual(values = change_colors) +
  geom_vline(xintercept = c(-logfc, logfc), lty = 2, 
             col = "black", linewidth = 0.4) +
  geom_hline(yintercept = -log10(p_cut), lty = 2, 
             col = "black", linewidth = 0.4) +
  theme_bw(base_size = 12, base_family = "Times") +
  theme(legend.position = "right", legend.direction = "vertical",
        legend.background = element_rect(fill = "white", 
                                         color = "white", linewidth = 0.2),
        panel.grid = element_blank(), legend.title = element_blank(),
        legend.text = element_text(face = "bold", color = "black", 
                                   family = "Times", size = 13),
        plot.title = element_text(hjust = 0.5, face = "bold", 
                                  color = "black", family = "Times", size=20),
        axis.text.x = element_text(face = "bold", color = "black", size=17),
        axis.text.y = element_text(face = "bold", color = "black", size=17),
        axis.title.x = element_text(face = "bold", 
                                    color = "black", family = "Times",size=20),
        axis.title.y = element_text(face = "bold", 
                                    color = "black", family = "Times",size=20),
        plot.subtitle = element_text(hjust = 0.5, family = "Times", 
                                     size=14,face="italic",colour="black")) +
  theme(text = element_text(family = "Times")) +
  labs(x = "log2 (FoldChange)", y = "-log10 (p.value)",
       title = paste0("GSE48000: ", group_order[1], " vs ", group_order[2]),
       subtitle = paste(sprintf('p.value: %.2f;', p_cut),
                        sprintf('log2 (FoldChange): %.2f;', logfc),
                        sprintf('Up: %1.0f; Down: %1.0f;', 
                                dim(up_DEG)[1], dim(down_DEG)[1]),
                        sprintf('Total: %1.0f', dim(dif)[1])))

suppressWarnings({
  ggsave("GSE48000_volcano.png", width = 7, height = 7)
  ggsave("GSE48000_volcano.pdf", width = 7, height = 7)})

## ⑧ 热图 -------------------------------
gene <- data_repel
select.expr <- expr[rownames(gene),]
condition$sample <- rownames(condition)
mat <- t(scale(t(select.expr)))
mat[mat < -2] <- -2; mat[mat > 2] <- 2
annotation_col <- data.frame(row.names=condition$sample,Group=condition$Group)
annotation_row <- data.frame(row.names=rownames(data_repel),sig=data_repel$sig)

group_order <- c("VTE", "Control")
condition$Group <- factor(condition$Group, levels = group_order)
condition <- condition[order(condition$Group), ]
mat <- mat[, condition$sample]
group_order_colors <- setNames(c("#FF7F00", "#1177b0"), group_order)

pdf('GSE48000_heat.pdf', w = 6, h = 7, family = 'Times')
draw(
  densityHeatmap(mat, title = "GSE48000: Distribution as heatmap",
                 ylab = " ", height = unit(6, "cm")) %v%
    HeatmapAnnotation(Group = annotation_col$Group, 
                      col = list(Group = group_order_colors)) %v%
    Heatmap(mat, row_names_gp = gpar(fontsize = 9), 
            show_column_names = F, show_row_names = T,
            name = "Expression", height = unit(8, "cm"),
            col = colorRampPalette(c("#0A878D", "white", "#D80305"))(100)))
dev.off()

png('GSE48000_heat.png', w = 6, h = 7, units = 'in', res = 600, family='Times')
draw(
  densityHeatmap(mat, title = "GSE48000: Distribution as heatmap", 
                 ylab = " ", height = unit(6, "cm")) %v%
    HeatmapAnnotation(Group = annotation_col$Group, 
                      col = list(Group = group_order_colors)) %v%
    Heatmap(mat, row_names_gp = gpar(fontsize = 9), 
            show_column_names = F, show_row_names = T,
            name = "Expression", height = unit(8, "cm"),
            col = colorRampPalette(c("#0A878D", "white", "#D80305"))(100)))
dev.off()

#============================================================================
