# ==================== 机器学习筛选核心基因（严格遵循原始代码） ====================
rm(list = ls())
setwd("/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3")

if (!dir.exists("ML")) dir.create("ML")
setwd("ML")

library(tidyverse)
library(glmnet)
library(randomForest)
library(xgboost)
library(gbm)
library(caret)
library(ggplot2)
library(ggsci)
library(reshape2)
library(VennDiagram)

# ==================== 1. 读取数据 ====================
train_expr <- read.csv("../data/expression_GSE19151.csv", row.names = 1, check.names = FALSE)
train_group <- read.csv("../data/group_GSE19151.csv", check.names = FALSE)
common_deg <- read.csv("../Venn/Common_DEGs.csv")$Gene

# 准备训练数据（与原始 ML.R 完全一致）
dat <- train_expr[rownames(train_expr) %in% common_deg, ] %>%
  t() %>% as.data.frame()
dat <- dat[rownames(dat) %in% train_group$sample, ]
dat$group <- factor(train_group$group[match(rownames(dat), train_group$sample)], 
                    levels = c("Control", "VTE"))
dat <- dat[, colSums(dat[, -ncol(dat)]) != 0]

# ==================== 2. LASSO（严格按原始代码） ====================
# ==================== LASSO（只显示 lambda.min） ====================
set.seed(123)
x <- as.matrix(dat[, -ncol(dat)])
y <- as.numeric(dat$group) - 1
cv_lasso <- cv.glmnet(x, y, family = "binomial", alpha = 1, nfolds = 10)

# 保存 lambda 值
lambda_min <- cv_lasso$lambda.min
lambda_1se <- cv_lasso$lambda.1se  # 保存但不用于绘图
write.csv(data.frame(lambda_min = lambda_min, lambda_1se = lambda_1se), 
          "LASSO_lambda.csv", row.names = FALSE)

# 提取系数
coef_min <- coef(cv_lasso, s = "lambda.min")
lasso_genes <- rownames(coef_min)[which(coef_min[, 1] != 0)][-1]
write.csv(data.frame(gene = lasso_genes), "LASSO_genes.csv", row.names = FALSE)
write.csv(data.frame(gene = rownames(coef_min)[-1], coefficient = as.vector(coef_min)[-1]), 
          "LASSO_coefficients.csv", row.names = FALSE)

# 准备系数路径数据
coef_path <- as.matrix(coef(cv_lasso$glmnet.fit, s = cv_lasso$glmnet.fit$lambda))
coef_path <- coef_path[-1, ]
coef_long <- melt(coef_path, varnames = c("gene", "step"), value.name = "coef")
coef_long$lambda <- cv_lasso$glmnet.fit$lambda[coef_long$step]
coef_long$loglambda <- log(coef_long$lambda)

# 获取非零基因数量与 lambda 的对应关系
nzero_df <- data.frame(loglambda = log(cv_lasso$lambda), nzero = cv_lasso$nzero)
# 选择几个关键点用于顶部标签（避免过密）
nzero_label <- nzero_df[seq(1, nrow(nzero_df), length.out = 6), ]

# 绘图：系数路径 + 顶部基因数量轴（只显示 lambda.min）
p1 <- ggplot(coef_long, aes(loglambda, coef, color = gene)) +
  geom_vline(xintercept = log(lambda_min), linetype = 2, color = "blue", size = 0.8) +
  geom_line(size = 1) +
  labs(x = "Log Lambda", y = "Coefficients") +
  theme_bw() +
  scale_color_manual(values = rep(pal_npg()(10), length(unique(coef_long$gene)))) +
  theme(legend.position = "none",
        axis.title = element_text(size = 14, face = "bold"),
        axis.text = element_text(size = 12)) +
  # 标注 lambda.min
  annotate("text", x = log(lambda_min) + 0.3, y = max(coef_long$coef) - 2,
           label = paste("lambda.min =", round(lambda_min, 4)), size = 4, hjust = 0, color = "blue") +
  # 顶部辅助轴：显示非零系数个数
  scale_x_continuous(sec.axis = sec_axis(~ ., 
                                         breaks = nzero_label$loglambda,
                                         labels = nzero_label$nzero,
                                         name = "Number of non-zero coefficients")) 

ggsave("LASSO_coef_path.pdf", p1, width = 9, height = 6)
ggsave("LASSO_coef_path.png", p1, width = 9, height = 6, dpi = 600)

# 交叉验证曲线（可选：也只显示 lambda.min 的竖线）
cv_df <- data.frame(loglambda = log(cv_lasso$lambda),
                    cvm = cv_lasso$cvm,
                    cvup = cv_lasso$cvup,
                    cvlo = cv_lasso$cvlo,
                    nzero = cv_lasso$nzero)
p2 <- ggplot(cv_df, aes(loglambda, cvm)) +
  geom_errorbar(aes(ymin = cvlo, ymax = cvup), width = 0.05, size = 0.8, color = "grey50") +
  geom_point(size = 2, color = "#E41A1C") +
  geom_vline(xintercept = log(lambda_min), linetype = 2, color = "blue", size = 0.8) +
  labs(x = "Log Lambda", y = "Partial Likelihood Deviance") +
  theme_bw() +
  annotate("text", x = log(lambda_min) + 0.3, y = max(cv_df$cvm) - 0.5,
           label = paste("lambda.min =", round(lambda_min, 4)), size = 4)
ggsave("LASSO_cv.pdf", p2, width = 8, height = 6)
ggsave("LASSO_cv.png", p2, width = 8, height = 6, dpi = 600)

cat("LASSO 筛选基因数：", length(lasso_genes), "\n")
# ==================== 3. Random Forest（严格按原始 ML.R） ====================
set.seed(123)
rf_model <- randomForest(group ~ ., data = dat, ntree = 500, importance = TRUE)
rf_importance <- importance(rf_model)
rf_imp_df <- data.frame(gene = rownames(rf_importance),
                        MeanDecreaseGini = rf_importance[, "MeanDecreaseGini"],
                        MeanDecreaseAccuracy = rf_importance[, "MeanDecreaseAccuracy"])
rf_imp_df <- rf_imp_df[order(rf_imp_df$MeanDecreaseGini, decreasing = TRUE), ]
write.csv(rf_imp_df, "RF_importance.csv", row.names = FALSE)

rf_genes <- rf_imp_df$gene[1:10]
write.csv(data.frame(gene = rf_genes), "RF_top10_genes.csv", row.names = FALSE)
cat("RF 筛选基因数：", length(rf_genes), "\n")

# RF 重要性图（前10）
rf_imp_top <- head(rf_imp_df, 10)
p3 <- ggplot(rf_imp_top, aes(x = reorder(gene, MeanDecreaseGini), y = MeanDecreaseGini)) +
  geom_bar(stat = "identity", fill = "#377EB8") +
  coord_flip() +
  labs(x = "Gene", y = "Mean Decrease Gini") +
  theme_bw() +
  theme(axis.text = element_text(size = 10),
        axis.title = element_text(size = 14, face = "bold"))
ggsave("RF_importance.pdf", p3, width = 8, height = 6)
ggsave("RF_importance.png", p3, width = 8, height = 6, dpi = 600)

# RF 误差图
pdf("RF_error.pdf", width = 6, height = 5)
plot(rf_model$err.rate[, 1], type = "l", xlab = "Number of Trees", ylab = "OOB Error",
     main = "Random Forest OOB Error")
dev.off()
png("RF_error.png", width = 6, height = 5, units = "in", res = 600)
plot(rf_model$err.rate[, 1], type = "l", xlab = "Number of Trees", ylab = "OOB Error",
     main = "Random Forest OOB Error")
dev.off()

# ==================== 4. XGBoost（严格按原始 ML.R） ====================
# ==================== 4. XGBoost（修正误差图） ====================
set.seed(123)
xgb_matrix <- xgb.DMatrix(data = as.matrix(dat[, -ncol(dat)]), 
                          label = as.numeric(dat$group) - 1)

# 添加 watchlist 以便记录训练过程中的误差
watchlist <- list(train = xgb_matrix)

xgb_model <- xgb.train(params = list(objective = "binary:logistic", max_depth = 3, eta = 0.1),
                       data = xgb_matrix, 
                       nrounds = 100, 
                       verbose = 1,          # 设置为1以输出日志，同时会记录 evaluation_log
                       watchlist = watchlist)

# 提取重要性
xgb_importance <- xgb.importance(feature_names = colnames(dat[, -ncol(dat)]), model = xgb_model)
write.csv(xgb_importance, "XGBoost_importance.csv", row.names = FALSE)

xgb_genes <- xgb_importance$Feature[1:10]
write.csv(data.frame(gene = xgb_genes), "XGBoost_top10_genes.csv", row.names = FALSE)
cat("XGBoost 筛选基因数：", length(xgb_genes), "\n")

# 重要性图
xgb_imp_top <- head(xgb_importance, 10)
p4 <- ggplot(xgb_imp_top, aes(x = reorder(Feature, Gain), y = Gain)) +
  geom_bar(stat = "identity", fill = "#4DAF4A") +
  coord_flip() +
  labs(x = "Gene", y = "Gain") +
  theme_bw() +
  theme(axis.text = element_text(size = 10),
        axis.title = element_text(size = 14, face = "bold"))
ggsave("XGBoost_importance.pdf", p4, width = 8, height = 6)
ggsave("XGBoost_importance.png", p4, width = 8, height = 6, dpi = 600)

# 训练误差曲线（从 evaluation_log 中提取）
if (!is.null(xgb_model$evaluation_log) && nrow(xgb_model$evaluation_log) > 0) {
  xgb_log <- xgb_model$evaluation_log
  # 检查列名，通常是 "iter" 和 "train_logloss"
  if (all(c("iter", "train_logloss") %in% colnames(xgb_log))) {
    p5 <- ggplot(xgb_log, aes(iter, train_logloss)) +
      geom_line(color = "#4DAF4A", size = 1) +
      labs(x = "Number of Trees", y = "Log Loss") +
      theme_bw()
    ggsave("XGBoost_error.pdf", p5, width = 6, height = 5)
    ggsave("XGBoost_error.png", p5, width = 6, height = 5, dpi = 600)
  } else {
    cat("警告：evaluation_log 列名不符合预期，跳过误差图。\n")
  }
} else {
  cat("警告：未找到 evaluation_log，跳过误差图。\n")
}
# ==================== 5. GBM（严格按原始 ML.R） ====================
set.seed(123)
gbm_data <- dat
gbm_data$group <- as.numeric(gbm_data$group) - 1
gbm_model <- gbm(group ~ ., data = gbm_data, distribution = "bernoulli",
                 n.trees = 500, interaction.depth = 3, shrinkage = 0.01, verbose = FALSE)
gbm_summary <- summary(gbm_model, plotit = FALSE)
write.csv(gbm_summary, "GBM_importance.csv", row.names = FALSE)

gbm_genes <- as.character(gbm_summary$var[1:10])
write.csv(data.frame(gene = gbm_genes), "GBM_top10_genes.csv", row.names = FALSE)
cat("GBM 筛选基因数：", length(gbm_genes), "\n")

# GBM 重要性图
gbm_imp_top <- head(gbm_summary, 10)
p6 <- ggplot(gbm_imp_top, aes(x = reorder(var, rel.inf), y = rel.inf)) +
  geom_bar(stat = "identity", fill = "#984EA3") +
  coord_flip() +
  labs(x = "Gene", y = "Relative Influence") +
  theme_bw() +
  theme(axis.text = element_text(size = 10),
        axis.title = element_text(size = 14, face = "bold"))
ggsave("GBM_importance.pdf", p6, width = 8, height = 6)
ggsave("GBM_importance.png", p6, width = 8, height = 6, dpi = 600)

# ==================== 6. KNN（严格按原始 ML.R） ====================
set.seed(123)
control <- rfeControl(functions = caretFuncs, method = "cv", number = 10)
knn_rfe <- rfe(dat[, -ncol(dat)], dat$group, 
               sizes = c(1:min(20, ncol(dat)-1)),
               rfeControl = control, method = "knn")
knn_genes <- predictors(knn_rfe)
if (length(knn_genes) > 10) knn_genes <- knn_genes[1:19]
write.csv(data.frame(gene = knn_genes), "KNN_top10_genes.csv", row.names = FALSE)

# 保存 RFE 结果
rfe_results <- data.frame(Variables = knn_rfe$results$Variables,
                          Accuracy = knn_rfe$results$Accuracy,
                          Kappa = knn_rfe$results$Kappa)
write.csv(rfe_results, "KNN_RFE_results.csv", row.names = FALSE)

# KNN 精度图
p7 <- ggplot(rfe_results, aes(Variables, Accuracy)) +
  geom_line(color = "#FF7F00", size = 1) +
  geom_point(size = 2, color = "#FF7F00") +
  labs(x = "Number of Variables", y = "Accuracy") +
  theme_bw()
ggsave("KNN_RFE_accuracy.pdf", p7, width = 6, height = 5)
ggsave("KNN_RFE_accuracy.png", p7, width = 6, height = 5, dpi = 600)

cat("KNN 筛选基因数：", length(knn_genes), "\n")

# ==================== 7. 取交集（与原始 ML.R 完全一致） ====================
lasso <- read.csv("LASSO_genes.csv")$gene
rf <- read.csv("RF_top10_genes.csv")$gene
xgb <- read.csv("XGBoost_top10_genes.csv")$gene
gbm <- read.csv("GBM_top10_genes.csv")$gene
knn <- read.csv("KNN_top10_genes.csv")$gene

common <- Reduce(intersect, list(lasso, rf, xgb, gbm, knn))

if (length(common) == 0) {
  all_genes <- c(lasso, rf, xgb, gbm, knn)
  freq <- table(all_genes)
  common <- names(sort(freq, decreasing = TRUE))[1:5]
  cat("\n交集为空，取出现频率最高的5个基因\n")
} else if (length(common) > 5) {
  common <- common[1:5]
}

write.csv(data.frame(gene = common), "core_genes.csv", row.names = FALSE)
cat("\n核心基因数：", length(common), "\n")
cat("核心基因：", paste(common, collapse = ", "), "\n")

# ==================== 8. Venn 图 ====================
areas <- c(length(lasso), length(rf), length(xgb), length(gbm), length(knn))
n12 <- length(intersect(lasso, rf))
n13 <- length(intersect(lasso, xgb))
n14 <- length(intersect(lasso, gbm))
n15 <- length(intersect(lasso, knn))
n23 <- length(intersect(rf, xgb))
n24 <- length(intersect(rf, gbm))
n25 <- length(intersect(rf, knn))
n34 <- length(intersect(xgb, gbm))
n35 <- length(intersect(xgb, knn))
n45 <- length(intersect(gbm, knn))

n123 <- length(Reduce(intersect, list(lasso, rf, xgb)))
n124 <- length(Reduce(intersect, list(lasso, rf, gbm)))
n125 <- length(Reduce(intersect, list(lasso, rf, knn)))
n134 <- length(Reduce(intersect, list(lasso, xgb, gbm)))
n135 <- length(Reduce(intersect, list(lasso, xgb, knn)))
n145 <- length(Reduce(intersect, list(lasso, gbm, knn)))
n234 <- length(Reduce(intersect, list(rf, xgb, gbm)))
n235 <- length(Reduce(intersect, list(rf, xgb, knn)))
n245 <- length(Reduce(intersect, list(rf, gbm, knn)))
n345 <- length(Reduce(intersect, list(xgb, gbm, knn)))

n1234 <- length(Reduce(intersect, list(lasso, rf, xgb, gbm)))
n1235 <- length(Reduce(intersect, list(lasso, rf, xgb, knn)))
n1245 <- length(Reduce(intersect, list(lasso, rf, gbm, knn)))
n1345 <- length(Reduce(intersect, list(lasso, xgb, gbm, knn)))
n2345 <- length(Reduce(intersect, list(rf, xgb, gbm, knn)))
n12345 <- length(common)

pdf("Venn_5algorithms.pdf", width = 10, height = 8)
draw.quintuple.venn(
  area1 = areas[1], area2 = areas[2], area3 = areas[3], area4 = areas[4], area5 = areas[5],
  n12 = n12, n13 = n13, n14 = n14, n15 = n15,
  n23 = n23, n24 = n24, n25 = n25, n34 = n34, n35 = n35, n45 = n45,
  n123 = n123, n124 = n124, n125 = n125, n134 = n134, n135 = n135,
  n145 = n145, n234 = n234, n235 = n235, n245 = n245, n345 = n345,
  n1234 = n1234, n1235 = n1235, n1245 = n1245, n1345 = n1345, n2345 = n2345,
  n12345 = n12345,
  category = c("LASSO", "RF", "XGBoost", "GBM", "KNN"),
  fill = c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00"),
  alpha = 0.5, cat.cex = 1.2, cex = 1, margin = 0.05)
dev.off()

png("Venn_5algorithms.png", width = 10, height = 8, units = "in", res = 600)
draw.quintuple.venn(
  area1 = areas[1], area2 = areas[2], area3 = areas[3], area4 = areas[4], area5 = areas[5],
  n12 = n12, n13 = n13, n14 = n14, n15 = n15,
  n23 = n23, n24 = n24, n25 = n25, n34 = n34, n35 = n35, n45 = n45,
  n123 = n123, n124 = n124, n125 = n125, n134 = n134, n135 = n135,
  n145 = n145, n234 = n234, n235 = n235, n245 = n245, n345 = n345,
  n1234 = n1234, n1235 = n1235, n1245 = n1245, n1345 = n1345, n2345 = n2345,
  n12345 = n12345,
  category = c("LASSO", "RF", "XGBoost", "GBM", "KNN"),
  fill = c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00"),
  alpha = 0.5, cat.cex = 1.2, cex = 1, margin = 0.05)
dev.off()

cat("\n所有分析完成！结果保存在 ML/ 文件夹下。\n")

