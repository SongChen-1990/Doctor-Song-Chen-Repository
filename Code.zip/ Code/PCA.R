# ==================== GSE19151 PCA 主成分分析 ====================
rm(list = ls())
setwd("/data/nas1/refinement12/shifuquan/111")
if (!dir.exists("./PCA")) dir.create("./PCA")
setwd("./PCA")

library(ggplot2)
library(ggpubr)

# 读取数据
expr <- read.csv("../data/expression_GSE19151.csv", 
                 row.names = 1, check.names = FALSE)
group <- read.csv("../data/group_GSE19151.csv", check.names = FALSE)

# PCA 分析
pca <- prcomp(t(expr), scale. = TRUE)
pca_df <- as.data.frame(pca$x)
pca_df$sample <- rownames(pca_df)
pca_df <- merge(pca_df, group, by = "sample")
pca_df$group <- factor(pca_df$group, levels = c("Control", "VTE"))

# 方差解释比例
var_exp <- round(pca$sdev^2 / sum(pca$sdev^2) * 100, 2)

# PCA 图
p <- ggplot(pca_df, aes(x = PC1, y = PC2, color = group)) +
  geom_point(size = 3, alpha = 0.8) +
  stat_ellipse(aes(fill = group), 
               type = "norm", geom = "polygon", alpha = 0.1) +
  scale_color_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  scale_fill_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  labs(x = paste0("PC1 (", var_exp[1], "%)"),
       y = paste0("PC2 (", var_exp[2], "%)"),
       title = "GSE19151: PCA Analysis") +
  theme_bw() +
  theme(legend.position = "right", 
        plot.title = element_text(hjust = 0.5, face = "bold", size = 14))

ggsave("GSE19151_PCA.pdf", p, width = 6, height = 5)
ggsave("GSE19151_PCA.png", p, width = 6, height = 5, dpi = 300)

# 统计结果
cat("PC1:", var_exp[1], "%, PC2:", var_exp[2], 
    "%, 累计:", var_exp[1] + var_exp[2], "%\n")
centers <- aggregate(pca_df[, c("PC1", "PC2")], 
                     by = list(group = pca_df$group), FUN = mean)
cat("Control 中心: (", round(centers$PC1[1], 2), 
    ",", round(centers$PC2[1], 2), ")\n")
cat("VTE 中心: (", round(centers$PC1[2], 2), ",",
    round(centers$PC2[2], 2), ")\n")
cat("组间距离:",round(sqrt(sum((centers[1,2:3] - centers[2,2:3])^2)),2),"\n")

#=========================================================================



# ==================== GSE48000 PCA 主成分分析 ====================
rm(list = ls())
setwd("/data/nas1/refinement12/shifuquan/111")
if (!dir.exists("./PCA")) dir.create("./PCA")
setwd("./PCA")

library(ggplot2)
library(ggpubr)

# 读取数据
expr <- read.csv("../data/expression_GSE48000.csv",
                 row.names = 1, check.names = FALSE)
group <- read.csv("../data/group_GSE48000.csv", check.names = FALSE)

# PCA 分析
pca <- prcomp(t(expr), scale. = TRUE)
pca_df <- as.data.frame(pca$x)
pca_df$sample <- rownames(pca_df)
pca_df <- merge(pca_df, group, by = "sample")
pca_df$group <- factor(pca_df$group, levels = c("Control", "VTE"))

# 方差解释比例
var_exp <- round(pca$sdev^2 / sum(pca$sdev^2) * 100, 2)

# PCA 图
p <- ggplot(pca_df, aes(x = PC1, y = PC2, color = group)) +
  geom_point(size = 3, alpha = 0.8) +
  stat_ellipse(aes(fill = group), type = "norm", 
               geom = "polygon", alpha = 0.1) +
  scale_color_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  scale_fill_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  labs(x = paste0("PC1 (", var_exp[1], "%)"),
       y = paste0("PC2 (", var_exp[2], "%)"),
       title = "GSE48000: PCA Analysis") +
  theme_bw() +
  theme(legend.position = "right", 
        plot.title = element_text(hjust = 0.5, face = "bold", size = 14))

ggsave("GSE48000_PCA.pdf", p, width = 6, height = 5)
ggsave("GSE48000_PCA.png", p, width = 6, height = 5, dpi = 300)

# 统计结果
cat("PC1:", var_exp[1], "%, PC2:", var_exp[2], 
    "%, 累计:", var_exp[1] + var_exp[2], "%\n")
centers <- aggregate(pca_df[, c("PC1", "PC2")],
                     by = list(group = pca_df$group), FUN = mean)
cat("Control 中心: (", round(centers$PC1[1], 2), 
    ",", round(centers$PC2[1], 2), ")\n")
cat("VTE 中心: (", round(centers$PC1[2], 2), 
    ",", round(centers$PC2[2], 2), ")\n")
cat("组间距离:",round(sqrt(sum((centers[1,2:3] - centers[2,2:3])^2)),2),"\n")

#==============================================================================