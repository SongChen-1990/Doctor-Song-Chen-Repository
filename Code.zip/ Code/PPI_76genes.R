# ==================== PPI分析 for 76 candidate genes (score=150) ====================
rm(list = ls())
setwd("/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3")

if(!dir.exists('./PPI_76genes')){
  dir.create('./PPI_76genes')
}
setwd('./PPI_76genes')

# 加载所需包
library(tidyverse)
library(curl)
library(circlize)
library(ComplexHeatmap)
library(Cairo)

# ==================== 1. 定义STRING API下载函数 ====================
get.string <- function(ids, score = 150, species = 9606){
  string_api_url <- "https://string-db.org/api"
  output_format <- "tsv"
  
  # 1. 映射标识符
  method <- paste0("get_string_ids?species=", species, "&identifiers=")
  identifiers <- paste0(ids, collapse = '%0d')
  url <- paste0(c(string_api_url, output_format, method), collapse = '/')
  url <- paste0(url, identifiers)
  tmp <- tempfile()
  curl::curl_download(url, tmp)
  identifiers <- read.delim2(tmp) %>% pull(preferredName) %>% paste0(collapse = '%0d')
  unlink(tmp)
  
  # 2. 获取网络互作数据
  method <- paste0("network?species=", species, "&required_score=", score, "&identifiers=")
  url <- paste0(c(string_api_url, output_format, method), collapse = '/')
  url <- paste0(url, identifiers)
  curl::curl_download(url, 'string_interactions.tsv')
  
  message("STRING data downloaded successfully with score=", score)
}

# ==================== 2. 读取76个候选基因（从 Common_DEGs.csv） ====================
gene_file <- "/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3/Venn/Common_DEGs.csv" 

candidate_genes <- read.csv(gene_file)
gene_list <- candidate_genes$Gene  # 列名为 Gene
cat("Number of candidate genes:", length(gene_list), "\n")

# ==================== 3. 下载PPI网络（置信度150） ====================
options(timeout = 9999999)
get.string(gene_list, score = 150, species = 9606)

# 读取下载的互作文件
string_data <- read_tsv('string_interactions.tsv') %>% 
  dplyr::select(preferredName_A, preferredName_B, score)
cat("Raw interactions:", nrow(string_data), "\n")

# ==================== 4. 定义绘图函数（弦图） ====================
# 参数 select_degree: 过滤时要求节点最小度数，默认1（即至少有一条边）
p_fun <- function(string_data, select_degree = 1){
  
  # 迭代过滤，直到所有节点度数 >= select_degree
  filtered_data <- string_data
  has_changes <- TRUE
  while(has_changes) {
    all_nodes <- c(filtered_data$preferredName_A, filtered_data$preferredName_B)
    node_degrees <- as.data.frame(table(all_nodes))
    colnames(node_degrees) <- c("node", "degree")
    nodes_to_keep <- node_degrees$node[node_degrees$degree >= select_degree]
    new_filtered_data <- filtered_data %>%
      filter(preferredName_A %in% nodes_to_keep & preferredName_B %in% nodes_to_keep)
    if(nrow(new_filtered_data) == nrow(filtered_data)) {
      has_changes <- FALSE
    } else {
      filtered_data <- new_filtered_data
    }
  }
  
  cat("Original edges:", nrow(string_data), "\n")
  cat("Filtered edges (degree >= ", select_degree, "):", nrow(filtered_data), "\n")
  
  final_nodes <- unique(c(filtered_data$preferredName_A, filtered_data$preferredName_B))
  final_degrees <- table(c(filtered_data$preferredName_A, filtered_data$preferredName_B))
  cat("Nodes retained:", length(final_nodes), "\n")
  cat("Node degrees:\n")
  print(final_degrees)
  
  if(nrow(filtered_data) == 0){
    stop("No edges after filtering. Try lowering select_degree or check input genes.")
  }
  
  # 准备弦图数据
  chord_data <- data.frame(
    from = filtered_data$preferredName_A,
    to = filtered_data$preferredName_B,
    value = filtered_data$score
  )
  
  all_genes <- unique(c(chord_data$from, chord_data$to))
  gene_connectivity <- table(c(chord_data$from, chord_data$to))
  gene_connectivity <- gene_connectivity[all_genes]
  sorted_genes <- names(sort(gene_connectivity, decreasing = TRUE))
  
  # 颜色设置
  connectivity_range <- range(gene_connectivity)
  connectivity_col_fun <- colorRamp2(
    breaks = c(connectivity_range[1], mean(connectivity_range), connectivity_range[2]),
    colors = c("blue", "green", "red")
  )
  sector_colors <- connectivity_col_fun(as.numeric(gene_connectivity))
  names(sector_colors) <- all_genes
  
  score_range <- range(chord_data$value)
  score_col_fun <- colorRamp2(
    breaks = c(score_range[1], mean(score_range), score_range[2]),
    colors = c("lightblue", "purple", "darkred")
  )
  
  # 绘图参数
  n_sectors <- length(all_genes)
  gap_degree <- min(2, 360/(n_sectors * 3))
  
  circos.clear()
  circos.par(gap.degree = gap_degree, start.degree = 90,
             canvas.xlim = c(-1, 1), canvas.ylim = c(-1.2, 1.2))
  
  chordDiagram(
    chord_data,
    grid.col = sector_colors,
    col = score_col_fun,
    transparency = 0.5,
    link.lwd = 1.5,
    link.lty = 1,
    link.sort = TRUE,
    link.decreasing = TRUE,
    annotationTrack = "grid",
    order = sorted_genes
  )
  
  # 添加外围标签
  circos.trackPlotRegion(
    track.index = 1,
    panel.fun = function(x, y) {
      sector.name <- get.cell.meta.data("sector.index")
      circos.text(
        x = mean(c(get.cell.meta.data("xlim"))),
        y = get.cell.meta.data("ylim")[1] + 1.2,
        labels = sector.name,
        facing = "clockwise",
        niceFacing = TRUE,
        adj = c(0, 0.5),
        cex = 0.7
      )
    },
    bg.border = NA
  )
  
  title("Protein-Protein Interaction Network (76 candidate genes, score>=150)", line = 0.3, cex.main = 1.2, font.main = 2)
  
  # 图例
  connectivity_legend <- Legend(
    title = "Degree",
    col_fun = connectivity_col_fun,
    at = round(seq(connectivity_range[1], connectivity_range[2], length = 5)),
    labels = round(seq(connectivity_range[1], connectivity_range[2], length = 5)),
    direction = "horizontal",
    title_position = "topcenter",
    title_gp = gpar(fontsize = 10, fontface = "bold"),
    labels_gp = gpar(fontsize = 8)
  )
  
  score_legend <- Legend(
    title = "Interaction Score",
    col_fun = score_col_fun,
    at = round(seq(score_range[1], score_range[2], length = 5), 3),
    labels = round(seq(score_range[1], score_range[2], length = 5), 3),
    direction = "horizontal",
    title_position = "topcenter",
    title_gp = gpar(fontsize = 10, fontface = "bold"),
    labels_gp = gpar(fontsize = 8)
  )
  
  legend_list <- packLegend(connectivity_legend, score_legend, direction = "vertical")
  pushViewport(viewport(x = 0.85, y = 0.15, width = 0.3, height = 0.3))
  draw(legend_list)
  popViewport()
  
  circos.clear()
}

# ==================== 5. 生成PPI弦图并保存 ====================
# 注意：若网络过于密集，可适当提高 select_degree 以简化图形
CairoPDF("PPI_76genes_score150.pdf", width = 9, height = 8)
p_fun(string_data, select_degree = 1)
dev.off()

CairoPNG("PPI_76genes_score150.png", width = 9, height = 6.5, units = "in", res = 600)
p_fun(string_data, select_degree = 1)
dev.off()

cat("\nPPI analysis completed. Output: PPI_76genes_score150.pdf / PPI_76genes_score150.png\n")
