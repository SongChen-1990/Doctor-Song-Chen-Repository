#====================================================
rm(list = ls())                                     
setwd("/data/nas1/refinement12/shifuquan/111")  
dir.create("Venn", showWarnings = FALSE)  
setwd("Venn") 

library(ggvenn)

## 读取差异基因
gse19151 <- read.csv("../DEG/GSE19151_DEGs_sig.csv", row.names = 1)
gse48000 <- read.csv("../DEG/GSE48000_DEGs_sig.csv", row.names = 1)

deg_19151 <- rownames(gse19151)
deg_48000 <- rownames(gse48000)

## 取交集
common <- intersect(deg_19151, deg_48000)
write.csv(data.frame(Gene = common), "Common_DEGs.csv", row.names = FALSE)

## Venn图
datalist <- list(GSE19151 = deg_19151, GSE48000 = deg_48000)

pdf('venn_DEG.pdf', w = 6, h = 5)
ggvenn(datalist,
       fill_color = c("#1f77b4", "#ff7f0e"),
       show_percentage = TRUE,
       digits = 2,
       fill_alpha = 0.5,
       stroke_size = 0.4,
       text_size = 5,
       set_name_size = 6)
dev.off()

png('venn_DEG.png', w = 6, h = 5, units = 'in', res = 300)
ggvenn(datalist,
       fill_color = c("#1f77b4", "#ff7f0e"),
       show_percentage = TRUE,
       digits = 2,
       fill_alpha = 0.5,
       stroke_size = 0.4,
       text_size = 5,
       set_name_size = 6)
dev.off()

#==========================================================================


# =========================================================================
rm(list = ls())  
setwd("/data/nas1/refinement12/shifuquan/111")
dir.create("Venn", showWarnings = FALSE)  
setwd("Venn") 

library(ggvenn)
library(openxlsx)

# 读取免疫基因集
immune_genes <- read.xlsx("immune_genes.xlsx", sheet = 1)$gene

# 读取共同差异基因
common_deg <- read.csv("Common_DEGs.csv")$Gene

# 取交集
immune_deg <- intersect(common_deg, immune_genes)
immune_deg_df <- data.frame(Gene = immune_deg)
write.csv(immune_deg_df, "Immune_DEGs.csv", row.names = FALSE)

# Venn图
datalist <- list(Common_DEGs = common_deg, Immune_Genes = immune_genes)

pdf('venn_immune.pdf', w = 6, h = 5)
ggvenn(datalist,
       fill_color = c("#4DAF4A", "#F781BF"),
       show_percentage = TRUE,
       digits = 2,
       fill_alpha = 0.5,
       stroke_size = 0.4,
       text_size = 5,
       set_name_size = 6)
dev.off()

png('venn_immune.png', w = 6, h = 5, units = 'in', res = 300)
ggvenn(datalist,
       fill_color = c("#4DAF4A", "#F781BF"),
       show_percentage = TRUE,
       digits = 2,
       fill_alpha = 0.5,
       stroke_size = 0.4,
       text_size = 5,
       set_name_size = 6)
dev.off()

#==========================================================================