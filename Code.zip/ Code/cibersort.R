# ==================== GSE19151 CIBERSORT 免疫浸润分析 ====================
rm(list = ls())
setwd("/data/nas1/refinement12/shifuquan/111")

# ==================== 创建目录 ====================
if (!dir.exists("CIBERSORT")) dir.create("CIBERSORT")
setwd("CIBERSORT")
if (!dir.exists("GSE19151")) dir.create("GSE19151")
setwd("GSE19151")

# ==================== 读取数据 ====================
train_expr <- read.csv("../../data/expression_GSE19151.csv",
                       row.names = 1, check.names = FALSE)
train_group <- read.csv("../../data/group_GSE19151.csv", check.names = FALSE)
hubgene <- c("LGALS3", "S100A12", "ISG15", "FCGR1A", "FOS", "LY96")

# 准备 CIBERSORT 输入
exprSet <- data.frame(gene = rownames(train_expr),
                      train_expr, check.names = FALSE)
exprSet <- na.omit(exprSet)
write.table(exprSet, "CIBERSORT_RNA.txt", 
            row.names = FALSE, quote = FALSE, sep = "\t")

# ==================== 运行 CIBERSORT ====================
source('CIBERSORT.R')
result <- CIBERSORT('LM22.txt', 'CIBERSORT_RNA.txt', perm = 1000, QN = TRUE)

immune_prop <- result[, 1:22]
write.csv(immune_prop, "01.CIBERSORT_result.csv", quote = FALSE)

# ==================== 数据预处理 ====================
immune_prop <- read.csv("01.CIBERSORT_result.csv", row.names = 1)
colnames(immune_prop) <- gsub('[.]', ' ', colnames(immune_prop))
immune_prop <- immune_prop[, order(colnames(immune_prop))]
immune_prop <- immune_prop[, colSums(immune_prop) > 0]

train_group <- train_group[, c("sample", "group")]
train_group <- train_group[order(train_group$sample), ]
rownames(train_group) <- train_group$sample
train_group <- train_group[rownames(immune_prop), ]

# ==================== 1. 免疫细胞组间差异 ====================
library(dplyr)
library(tidyr)
library(rstatix)
library(ggpubr)
library(tibble)

dat <- immune_prop %>%
  as.data.frame() %>%
  rownames_to_column("sample") %>%
  inner_join(train_group, by = "sample") %>%
  pivot_longer(cols = -c(sample, group), 
               names_to = "Cell", values_to = "Proportion")

stat_res <- dat %>%
  group_by(Cell) %>%
  wilcox_test(Proportion ~ group) %>%
  adjust_pvalue(method = "BH") %>%
  add_significance("p")

write.table(stat_res, "02.cell_wilcoxon_res.xls", 
            sep = "\t", row.names = FALSE, quote = FALSE)

# 箱线图
p_box <- ggboxplot(dat, x = "Cell", y = "Proportion", 
                   fill = "group",
                   palette = c("#FF7F00", "#4DAF4A"),
                   outlier.shape = NA, 
                   bxp.errorbar = TRUE) +
  stat_pvalue_manual(stat_res, x = "Cell", 
                     y.position = max(dat$Proportion) * 1.1,
                     label = "p.signif", size = 3) +
  labs(x = "", y = "Immune Cell Proportion", 
       title = "GSE19151: Immune Cell Infiltration") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, 
                                   hjust = 1, size = 9, face = "bold"),
        axis.text.y = element_text(size = 10, face = "bold"),
        axis.title = element_text(size = 12, face = "bold"),
        legend.title = element_blank(),
        legend.position = "top",
        panel.grid = element_blank(),
        plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("03.cell_boxplot.pdf", p_box, width = 14, height = 7)
ggsave("03.cell_boxplot.png", p_box, width = 14, height = 7, dpi = 300)

# ==================== 2. 免疫细胞间相关性 ====================
library(psych)
library(corrplot)

immune_all <- immune_prop
corr_all <- corr.test(immune_all, method = "spearman")

sig_mat <- corr_all$p
sig_mat[abs(corr_all$r) <= 0.3] <- 1
sig_mat[sig_mat >= 0.05] <- 1

col_fun <- colorRampPalette(c("#2166AC", "white", "#B2182B"))(50)

pdf("04.cell_correlation.pdf", width = 14, height = 14)
corrplot(corr_all$r, p.mat = sig_mat, type = "upper",
         col = col_fun, tl.pos = "lt", tl.col = "black",
         insig = "label_sig", sig.level = c(0.05, 0.01, 0.001),
         pch.cex = 0.9, pch.col = "black", tl.cex = 0.9, cl.cex = 0.9)
corrplot(corr_all$r, type = "lower", add = TRUE, method = "number",
         col = col_fun, tl.pos = "n", diag = FALSE, cl.pos = "n",
         number.cex = 0.7)
dev.off()

png("04.cell_correlation.png", width = 14, height = 14, units = "in", res = 600)
corrplot(corr_all$r, p.mat = sig_mat, type = "upper",
         col = col_fun, tl.pos = "lt", tl.col = "black",
         insig = "label_sig", sig.level = c(0.05, 0.01, 0.001),
         pch.cex = 0.9, pch.col = "black", tl.cex = 0.9, cl.cex = 0.9)
corrplot(corr_all$r, type = "lower", add = TRUE, method = "number",
         col = col_fun, tl.pos = "n", diag = FALSE, cl.pos = "n",
         number.cex = 0.7)
dev.off()

# ==================== 3. Hub基因与免疫细胞相关性 ====================
hub_exp <- train_expr[rownames(train_expr) %in% hubgene, ] %>%
  t() %>% as.data.frame()
hub_exp <- hub_exp[rownames(immune_prop), hubgene]

d <- corr.test(hub_exp, immune_prop, method = "spearman", adjust = "BH")

r <- d$r
p <- d$p

write.csv(r, "05.hubgene_cell_r.csv", quote = FALSE)
write.csv(p, "05.hubgene_cell_pvalue.csv", quote = FALSE)

# 显著性标注矩阵（|cor| > 0.3 且 p < 0.05 标注）
sig_mat_hub <- p
sig_mat_hub[abs(r) <= 0.3] <- 1
sig_mat_hub[sig_mat_hub >= 0.05] <- 1

# 配色：正相关红色，负相关蓝色
col <- colorRampPalette(c("blue", "white", "red"))(100)

pdf("06.hubgene_cell_correlation.pdf", width = 12, height = 8)
corrplot(r, p.mat = sig_mat_hub, insig = "label_sig",
         sig.level = c(0.05, 0.01, 0.001), pch.cex = 0.8,
         tl.cex = 0.8, tl.col = "black", tl.srt = 45,
         cl.cex = 0.8, mar = c(0, 0, 0, 0),
         col = col)
dev.off()

png("06.hubgene_cell_correlation.png", 
    width = 12, height = 8, units = "in", res = 600)
corrplot(r, p.mat = sig_mat_hub, insig = "label_sig",
         sig.level = c(0.05, 0.01, 0.001), pch.cex = 0.8,
         tl.cex = 0.8, tl.col = "black", tl.srt = 45,
         cl.cex = 0.8, mar = c(0, 0, 0, 0),
         col = col)
dev.off()

# ==================== GSE19151 统计 ====================
# 差异免疫细胞
sig_cells <- stat_res[stat_res$p < 0.05, ]
cat("差异免疫细胞数：", nrow(sig_cells), "\n")
cat("差异免疫细胞：", paste(sig_cells$Cell, collapse = ", "), "\n\n")

# 免疫细胞间相关性（|cor| > 0.3, p < 0.05）
r_filt <- corr_all$r
r_filt[abs(r_filt) <= 0.3 | corr_all$p >= 0.05] <- NA
r_filt[lower.tri(r_filt, diag = TRUE)] <- NA
corr_df <- na.omit(data.frame(
  cell1 = rep(rownames(r_filt), each = ncol(r_filt)),
  cell2 = rep(colnames(r_filt), times = nrow(r_filt)),
  cor = as.vector(r_filt)
))

if (nrow(corr_df) > 0) {
  cat("强显著正相关：", corr_df[which.max(corr_df$cor), "cell1"], "vs", 
      corr_df[which.max(corr_df$cor), "cell2"], "cor =", round(max(corr_df$cor), 2), "\n")
  cat("强显著负相关：", corr_df[which.min(corr_df$cor), "cell1"], "vs", 
      corr_df[which.min(corr_df$cor), "cell2"], "cor =", round(min(corr_df$cor), 2), "\n\n")
} else {
  cat("无强显著相关\n\n")
}

#===========================================================================





# ==================== GSE48000 CIBERSORT 免疫浸润分析 ====================
rm(list = ls())
setwd("/data/nas1/refinement12/shifuquan/111")

# ==================== 创建目录 ====================
if (!dir.exists("CIBERSORT")) dir.create("CIBERSORT")
setwd("CIBERSORT")
if (!dir.exists("GSE48000")) dir.create("GSE48000")
setwd("GSE48000")

# ==================== 读取数据 ====================
train_expr <- read.csv("../../data/expression_GSE48000.csv",
                       row.names = 1, check.names = FALSE)
train_group <- read.csv("../../data/group_GSE48000.csv", check.names = FALSE)
hubgene <- c("LGALS3", "S100A12", "ISG15", "FCGR1A", "FOS", "LY96")

# 准备 CIBERSORT 输入
exprSet <- data.frame(gene = rownames(train_expr),
                      train_expr, check.names = FALSE)
exprSet <- na.omit(exprSet)
write.table(exprSet, "CIBERSORT_RNA.txt", 
            row.names = FALSE, quote = FALSE, sep = "\t")

# ==================== 运行 CIBERSORT ====================
source('CIBERSORT.R')
result <- CIBERSORT('LM22.txt', 'CIBERSORT_RNA.txt', perm = 1000, QN = TRUE)

immune_prop <- result[, 1:22]
write.csv(immune_prop, "01.CIBERSORT_result.csv", quote = FALSE)

# ==================== 数据预处理 ====================
immune_prop <- read.csv("01.CIBERSORT_result.csv", row.names = 1)
colnames(immune_prop) <- gsub('[.]', ' ', colnames(immune_prop))
immune_prop <- immune_prop[, order(colnames(immune_prop))]
immune_prop <- immune_prop[, colSums(immune_prop) > 0]

train_group <- train_group[, c("sample", "group")]
train_group <- train_group[order(train_group$sample), ]
rownames(train_group) <- train_group$sample
train_group <- train_group[rownames(immune_prop), ]

# ==================== 1. 免疫细胞组间差异 ====================
library(dplyr)
library(tidyr)
library(rstatix)
library(ggpubr)

dat <- immune_prop %>%
  as.data.frame() %>%
  rownames_to_column("sample") %>%
  inner_join(train_group, by = "sample") %>%
  pivot_longer(cols = -c(sample, group), 
               names_to = "Cell", values_to = "Proportion")

stat_res <- dat %>%
  group_by(Cell) %>%
  wilcox_test(Proportion ~ group) %>%
  adjust_pvalue(method = "BH") %>%
  add_significance("p")

write.table(stat_res, "02.cell_wilcoxon_res.xls", 
            sep = "\t", row.names = FALSE, quote = FALSE)

# 箱线图
p_box <- ggboxplot(dat, x = "Cell", y = "Proportion", 
                   fill = "group",
                   palette = c("#FF7F00", "#4DAF4A"),
                   outlier.shape = NA, 
                   bxp.errorbar = TRUE) +
  stat_pvalue_manual(stat_res, x = "Cell", 
                     y.position = max(dat$Proportion) * 1.1,
                     label = "p.signif", size = 3) +
  labs(x = "", y = "Immune Cell Proportion", 
       title = "GSE48000: Immune Cell Infiltration") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, 
                                   hjust = 1, size = 9, face = "bold"),
        axis.text.y = element_text(size = 10, face = "bold"),
        axis.title = element_text(size = 12, face = "bold"),
        legend.title = element_blank(),
        legend.position = "top",
        panel.grid = element_blank(),
        plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("03.cell_boxplot.pdf", p_box, width = 14, height = 7)
ggsave("03.cell_boxplot.png", p_box, width = 14, height = 7, dpi = 300)

# ==================== 2. 免疫细胞间相关性 ====================
library(psych)
library(corrplot)

immune_all <- immune_prop
corr_all <- corr.test(immune_all, method = "spearman")

sig_mat <- corr_all$p
sig_mat[abs(corr_all$r) <= 0.3] <- 1
sig_mat[sig_mat >= 0.05] <- 1

col_fun <- colorRampPalette(c("#2166AC", "white", "#B2182B"))(50)

pdf("04.cell_correlation.pdf", width = 14, height = 14)
corrplot(corr_all$r, p.mat = sig_mat, type = "upper",
         col = col_fun, tl.pos = "lt", tl.col = "black",
         insig = "label_sig", sig.level = c(0.05, 0.01, 0.001),
         pch.cex = 0.9, pch.col = "black", tl.cex = 0.9, cl.cex = 0.9)
corrplot(corr_all$r, type = "lower", add = TRUE, method = "number",
         col = col_fun, tl.pos = "n", diag = FALSE, cl.pos = "n",
         number.cex = 0.7)
dev.off()

png("04.cell_correlation.png", width = 14, height = 14, units = "in", res = 600)
corrplot(corr_all$r, p.mat = sig_mat, type = "upper",
         col = col_fun, tl.pos = "lt", tl.col = "black",
         insig = "label_sig", sig.level = c(0.05, 0.01, 0.001),
         pch.cex = 0.9, pch.col = "black", tl.cex = 0.9, cl.cex = 0.9)
corrplot(corr_all$r, type = "lower", add = TRUE, method = "number",
         col = col_fun, tl.pos = "n", diag = FALSE, cl.pos = "n",
         number.cex = 0.7)
dev.off()

# ==================== 3. Hub基因与免疫细胞相关性 ====================
hub_exp <- train_expr[rownames(train_expr) %in% hubgene, ] %>%
  t() %>% as.data.frame()
hub_exp <- hub_exp[rownames(immune_prop), hubgene]

d <- corr.test(hub_exp, immune_prop, method = "spearman", adjust = "BH")

r <- d$r
p <- d$p

write.csv(r, "05.hubgene_cell_r.csv", quote = FALSE)
write.csv(p, "05.hubgene_cell_pvalue.csv", quote = FALSE)

# 显著性标注矩阵（|cor| > 0.3 且 p < 0.05 标注）
sig_mat_hub <- p
sig_mat_hub[abs(r) <= 0.3] <- 1
sig_mat_hub[sig_mat_hub >= 0.05] <- 1

# 配色：正相关红色，负相关蓝色，白色无相关
col <- colorRampPalette(c("blue", "white", "red"))(100)

pdf("06.hubgene_cell_correlation.pdf", width = 12, height = 8)
corrplot(r, p.mat = sig_mat_hub, insig = "label_sig",
         sig.level = c(0.05, 0.01, 0.001), pch.cex = 0.8,
         tl.cex = 0.8, tl.col = "black", tl.srt = 45,
         cl.cex = 0.8, mar = c(0, 0, 0, 0),
         col = col)
dev.off()

png("06.hubgene_cell_correlation.png", 
    width = 12, height = 8, units = "in", res = 600)
corrplot(r, p.mat = sig_mat_hub, insig = "label_sig",
         sig.level = c(0.05, 0.01, 0.001), pch.cex = 0.8,
         tl.cex = 0.8, tl.col = "black", tl.srt = 45,
         cl.cex = 0.8, mar = c(0, 0, 0, 0),
         col = col)
dev.off()

# ==================== GSE48000 统计 ====================
# 差异免疫细胞
sig_cells <- stat_res[stat_res$p < 0.05, ]
cat("差异免疫细胞数：", nrow(sig_cells), "\n")
cat("差异免疫细胞：", paste(sig_cells$Cell, collapse = ", "), "\n\n")

# 免疫细胞间相关性（|cor| > 0.3, p < 0.05）
corr_upper <- corr_all$r
corr_upper[lower.tri(corr_upper, diag = TRUE)] <- NA
corr_df <- data.frame(
  cell1 = rep(rownames(corr_upper), each = ncol(corr_upper)),
  cell2 = rep(colnames(corr_upper), times = nrow(corr_upper)),
  cor = as.vector(corr_upper),
  p = as.vector(corr_all$p))
corr_df <- na.omit(corr_df)
corr_df <- corr_df[corr_df$p < 0.05 & abs(corr_df$cor) > 0.3, ]

if (any(corr_df$cor > 0)) {
  cat("强显著正相关：", corr_df[which.max(corr_df$cor), "cell1"], "vs", 
      corr_df[which.max(corr_df$cor), 
              "cell2"], "cor =", round(max(corr_df$cor), 2), "\n")
} else {
  cat("无强显著正相关\n")
}
if (any(corr_df$cor < 0)) {
  cat("强显著负相关：", corr_df[which.min(corr_df$cor), "cell1"], "vs", 
      corr_df[which.min(corr_df$cor), 
              "cell2"], "cor =", round(min(corr_df$cor), 2), "\n\n")
} else {
  cat("无强显著负相关\n\n")
}

# ==========================================================================
