# ==================== 4个核心基因表达水平图及单基因ROC曲线 ====================
rm(list = ls())
setwd("/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3")

if (!dir.exists("core4_analysis")) dir.create("core4_analysis")
setwd("core4_analysis")

library(ggplot2)
library(ggpubr)
library(pROC)
library(caret)
library(tidyverse)

# 定义4个核心基因
core_genes <- c("BFAR", "CXorf21", "PIP5K1A", "UBFD1")

# ==================== 1. 读取训练集GSE19151数据 ====================
expr <- read.csv("../data/expression_GSE19151.csv", 
                 row.names = 1, check.names = FALSE)
group <- read.csv("../data/group_GSE19151.csv", check.names = FALSE)

# 提取核心基因表达并合并分组
expr_sub <- expr[rownames(expr) %in% core_genes, ] %>%
  t() %>% as.data.frame()
expr_sub$sample <- rownames(expr_sub)
expr_sub <- merge(expr_sub, group, by = "sample")
expr_sub$group <- factor(expr_sub$group, levels = c("Control", "VTE"))

# 转换为长格式
expr_long <- expr_sub %>%
  pivot_longer(cols = all_of(core_genes), 
               names_to = "gene", values_to = "expression")

# ==================== 2. 绘制表达水平图（合并为一个图） ====================
# 计算每个基因的最大表达值，用于调整显著性标签位置
max_per_gene <- expr_long %>%
  group_by(gene) %>%
  summarise(max_expr = max(expression, na.rm = TRUE))

p_expr <- ggplot(expr_long, aes(x = group, y = expression, fill = group)) +
  geom_boxplot(outlier.shape = NA, alpha = 0.7, width = 0.6) +
  geom_jitter(width = 0.15, size = 1.2, alpha = 0.6, color = "black") +
  stat_compare_means(method = "wilcox.test", label = "p.signif", 
                     comparisons = list(c("Control", "VTE")),
                     label.y = max_per_gene$max_expr * 0.92) +
  facet_wrap(~ gene, scales = "free_y", nrow = 2, ncol = 2) +
  scale_fill_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.15))) +
  labs(x = "", y = "Expression Level (log2 normalized)",
       title = "GSE19151: Expression of 4 core genes") +
  theme_bw() +
  theme(legend.position = "bottom",
        strip.text = element_text(face = "bold", size = 12),
        axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("4core_genes_expression_GSE19151.pdf", p_expr, width = 10, height = 8)
ggsave("4core_genes_expression_GSE19151.png", p_expr, width = 10, height = 8, dpi = 600)

# 输出表达统计结果
cat("\n========== 表达统计 (GSE19151) ==========\n")
expr_stats <- data.frame()
for (gene in core_genes) {
  control_vals <- expr_sub[expr_sub$group == "Control", gene]
  vte_vals <- expr_sub[expr_sub$group == "VTE", gene]
  control_mean <- mean(control_vals)
  vte_mean <- mean(vte_vals)
  log2fc <- log2(vte_mean / control_mean)
  p_val <- wilcox.test(vte_vals, control_vals)$p.value
  trend <- ifelse(vte_mean > control_mean, "高表达", "低表达")
  expr_stats <- rbind(expr_stats, data.frame(
    Gene = gene,
    Control_Mean = round(control_mean, 4),
    VTE_Mean = round(vte_mean, 4),
    log2FC = round(log2fc, 4),
    P_value = format(p_val, scientific = TRUE, digits = 3),
    Trend = trend
  ))
  cat(gene, ": VTE mean =", round(vte_mean, 3), 
      ", Control mean =", round(control_mean, 3),
      ", log2FC =", round(log2fc, 3),
      ", p =", format(p_val, scientific = TRUE, digits = 3),
      ",", trend, "\n")
}
write.csv(expr_stats, "4core_genes_expression_stats_GSE19151.csv", row.names = FALSE)

# BFAR : VTE mean = 8.976 , Control mean = 8.392 , log2FC = 0.097 , p = 1.54e-16 , 高表达 
# CXorf21 : VTE mean = 7.623 , Control mean = 7.093 , log2FC = 0.104 , p = 8.07e-14 , 高表达 
# PIP5K1A : VTE mean = 6.649 , Control mean = 7.189 , log2FC = -0.113 , p = 8.6e-18 , 低表达 
# UBFD1 : VTE mean = 6.588 , Control mean = 5.984 , log2FC = 0.139 , p = 2.4e-14 , 高表达








# ==================== 1. 读取训练集GSE19151数据 ====================
expr <- read.csv("../data/expression_GSE48000.csv", 
                 row.names = 1, check.names = FALSE)
group <- read.csv("../data/group_GSE48000.csv", check.names = FALSE)

# 提取核心基因表达并合并分组
expr_sub <- expr[rownames(expr) %in% core_genes, ] %>%
  t() %>% as.data.frame()
expr_sub$sample <- rownames(expr_sub)
expr_sub <- merge(expr_sub, group, by = "sample")
expr_sub$group <- factor(expr_sub$group, levels = c("Control", "VTE"))

# 转换为长格式
expr_long <- expr_sub %>%
  pivot_longer(cols = all_of(core_genes), 
               names_to = "gene", values_to = "expression")

# ==================== 2. 绘制表达水平图（合并为一个图） ====================
# 计算每个基因的最大表达值，用于调整显著性标签位置
max_per_gene <- expr_long %>%
  group_by(gene) %>%
  summarise(max_expr = max(expression, na.rm = TRUE))

p_expr <- ggplot(expr_long, aes(x = group, y = expression, fill = group)) +
  geom_boxplot(outlier.shape = NA, alpha = 0.7, width = 0.6) +
  geom_jitter(width = 0.15, size = 1.2, alpha = 0.6, color = "black") +
  stat_compare_means(method = "wilcox.test", label = "p.signif", 
                     comparisons = list(c("Control", "VTE")),
                     label.y = max_per_gene$max_expr * 0.92) +
  facet_wrap(~ gene, scales = "free_y", nrow = 2, ncol = 2) +
  scale_fill_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.15))) +
  labs(x = "", y = "Expression Level (log2 normalized)",
       title = "GSE48000: Expression of 4 core genes") +
  theme_bw() +
  theme(legend.position = "bottom",
        strip.text = element_text(face = "bold", size = 12),
        axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("4core_genes_expression_GSE48000.pdf", p_expr, width = 10, height = 8)
ggsave("4core_genes_expression_GSE48000.png", p_expr, width = 10, height = 8, dpi = 600)

# 输出表达统计结果
cat("\n========== 表达统计 (GSE48000) ==========\n")
expr_stats <- data.frame()
for (gene in core_genes) {
  control_vals <- expr_sub[expr_sub$group == "Control", gene]
  vte_vals <- expr_sub[expr_sub$group == "VTE", gene]
  control_mean <- mean(control_vals)
  vte_mean <- mean(vte_vals)
  log2fc <- log2(vte_mean / control_mean)
  p_val <- wilcox.test(vte_vals, control_vals)$p.value
  trend <- ifelse(vte_mean > control_mean, "高表达", "低表达")
  expr_stats <- rbind(expr_stats, data.frame(
    Gene = gene,
    Control_Mean = round(control_mean, 4),
    VTE_Mean = round(vte_mean, 4),
    log2FC = round(log2fc, 4),
    P_value = format(p_val, scientific = TRUE, digits = 3),
    Trend = trend
  ))
  cat(gene, ": VTE mean =", round(vte_mean, 3), 
      ", Control mean =", round(control_mean, 3),
      ", log2FC =", round(log2fc, 3),
      ", p =", format(p_val, scientific = TRUE, digits = 3),
      ",", trend, "\n")
}
write.csv(expr_stats, "4core_genes_expression_stats_GSE48000.csv", row.names = FALSE)

# BFAR : VTE mean = 10.57 , Control mean = 9.931 , log2FC = 0.09 , p = 3.39e-04 , 高表达 
# CXorf21 : VTE mean = 8.25 , Control mean = 7.7 , log2FC = 0.1 , p = 1.93e-04 , 高表达 
# PIP5K1A : VTE mean = 7.96 , Control mean = 7.438 , log2FC = 0.098 , p = 5.8e-03 , 高表达 
# UBFD1 : VTE mean = 8.513 , Control mean = 7.743 , log2FC = 0.137 , p = 8.57e-04 , 高表达 
