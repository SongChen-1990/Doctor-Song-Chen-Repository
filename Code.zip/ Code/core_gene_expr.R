# ==================== 核心基因表达水平图绘制 ====================
rm(list = ls())
setwd("/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3")

if (!dir.exists("core_gene_expr")) dir.create("core_gene_expr")
setwd("core_gene_expr")

library(ggplot2)
library(ggpubr)
library(tidyverse)

# 定义6个核心基因
core_genes <- c("LGALS3", "S100A12", "ISG15", "FCGR1A", "FOS", "LY96")

# ==================== 1. GSE19151 数据集 ====================
# 读取表达矩阵和分组信息
expr_19151 <- read.csv("../data/expression_GSE19151.csv", 
                       row.names = 1, check.names = FALSE)
group_19151 <- read.csv("../data/group_GSE19151.csv", check.names = FALSE)

# 提取核心基因表达数据并转置
expr_sub_19151 <- expr_19151[rownames(expr_19151) %in% core_genes, ] %>%
  t() %>% as.data.frame()
expr_sub_19151$sample <- rownames(expr_sub_19151)
expr_sub_19151 <- merge(expr_sub_19151, group_19151, by = "sample")
expr_sub_19151$group <- factor(expr_sub_19151$group, levels = c("Control", "VTE"))

# 转换为长格式用于绘图
expr_long_19151 <- expr_sub_19151 %>%
  pivot_longer(cols = all_of(core_genes), 
               names_to = "gene", values_to = "expression")

# 绘制箱线图（带散点）
p_19151 <- ggplot(expr_long_19151, aes(x = group, y = expression, fill = group)) +
  geom_boxplot(outlier.shape = NA, alpha = 0.7, width = 0.6) +
  geom_jitter(width = 0.15, size = 1.2, alpha = 0.6, color = "black") +
  stat_compare_means(method = "wilcox.test", label = "p.signif", 
                     comparisons = list(c("Control", "VTE")),
                     label.y = max(expr_long_19151$expression) * 1.05) +
  facet_wrap(~ gene, scales = "free_y", nrow = 2, ncol = 3) +
  scale_fill_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  labs(x = "", y = "Expression Level (log2 normalized)",
       title = "GSE19151: Expression of core genes") +
  theme_bw() +
  theme(legend.position = "bottom",
        strip.text = element_text(face = "bold", size = 12),
        axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("GSE19151_core_genes_expression.pdf", p_19151, width = 15, height = 10)
ggsave("GSE19151_core_genes_expression.png", p_19151, width = 15, height = 10, dpi = 600)

# 输出各组表达均值和显著性
cat("\n========== GSE19151 ==========\n")
for (gene in core_genes) {
  control_mean <- mean(expr_sub_19151[expr_sub_19151$group == "Control", gene])
  vte_mean <- mean(expr_sub_19151[expr_sub_19151$group == "VTE", gene])
  cat(gene, ": Control mean =", round(control_mean, 3), 
      ", VTE mean =", round(vte_mean, 3),
      ", log2FC =", round(log2(vte_mean / control_mean), 3),
      ifelse(vte_mean > control_mean, "(高表达)", "(低表达)"), "\n")
}

# LGALS3 : Control mean = 12.23 , VTE mean = 12.98 , log2FC = 0.087 (高表达) 
# S100A12 : Control mean = 10.32 , VTE mean = 11.37 , log2FC = 0.139 (高表达) 
# ISG15 : Control mean = 9.752 , VTE mean = 10.27 , log2FC = 0.075 (高表达) 
# FCGR1A : Control mean = 6.496 , VTE mean = 7.192 , log2FC = 0.147 (高表达) 
# FOS : Control mean = 9.738 , VTE mean = 8.995 , log2FC = -0.114 (低表达) 
# LY96 : Control mean = 7.292 , VTE mean = 8.602 , log2FC = 0.238 (高表达) 



# ==================== 2. GSE48000 数据集 ====================
expr_48000 <- read.csv("../data/expression_GSE48000.csv", 
                       row.names = 1, check.names = FALSE)
group_48000 <- read.csv("../data/group_GSE48000.csv", check.names = FALSE)

# 提取核心基因表达数据
expr_sub_48000 <- expr_48000[rownames(expr_48000) %in% core_genes, ] %>%
  t() %>% as.data.frame()
expr_sub_48000$sample <- rownames(expr_sub_48000)
expr_sub_48000 <- merge(expr_sub_48000, group_48000, by = "sample")
expr_sub_48000$group <- factor(expr_sub_48000$group, levels = c("Control", "VTE"))

# 长格式
expr_long_48000 <- expr_sub_48000 %>%
  pivot_longer(cols = all_of(core_genes), 
               names_to = "gene", values_to = "expression")

# 绘图
p_48000 <- ggplot(expr_long_48000, aes(x = group, y = expression, fill = group)) +
  geom_boxplot(outlier.shape = NA, alpha = 0.7, width = 0.6) +
  geom_jitter(width = 0.15, size = 1.2, alpha = 0.6, color = "black") +
  stat_compare_means(method = "wilcox.test", label = "p.signif", 
                     comparisons = list(c("Control", "VTE")),
                     label.y = max(expr_long_48000$expression) * 1.05) +
  facet_wrap(~ gene, scales = "free_y", nrow = 2, ncol = 3) +
  scale_fill_manual(values = c("Control" = "#4DAF4A", "VTE" = "#FF7F00")) +
  labs(x = "", y = "Expression Level (log2 normalized)",
       title = "GSE48000: Expression of core genes") +
  theme_bw() +
  theme(legend.position = "bottom",
        strip.text = element_text(face = "bold", size = 12),
        axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("GSE48000_core_genes_expression.pdf", p_48000, width = 15, height = 10)
ggsave("GSE48000_core_genes_expression.png", p_48000, width = 15, height = 10, dpi = 600)

# 输出各组表达均值和表达趋势
cat("\n========== GSE48000 ==========\n")
for (gene in core_genes) {
  control_mean <- mean(expr_sub_48000[expr_sub_48000$group == "Control", gene])
  vte_mean <- mean(expr_sub_48000[expr_sub_48000$group == "VTE", gene])
  cat(gene, ": Control mean =", round(control_mean, 3), 
      ", VTE mean =", round(vte_mean, 3),
      ", log2FC =", round(log2(vte_mean / control_mean), 3),
      ifelse(vte_mean > control_mean, "(高表达)", "(低表达)"), "\n")
}

cat("\n所有图片已保存至 core_gene_expr/ 目录\n")
# LGALS3 : Control mean = 11.78 , VTE mean = 12.3 , log2FC = 0.062 (高表达) 
# S100A12 : Control mean = 12.54 , VTE mean = 13.28 , log2FC = 0.084 (高表达) 
# ISG15 : Control mean = 10.7 , VTE mean = 11.21 , log2FC = 0.068 (高表达) 
# FCGR1A : Control mean = 9.693 , VTE mean = 10.48 , log2FC = 0.113 (高表达) 
# FOS : Control mean = 10.79 , VTE mean = 9.976 , log2FC = -0.113 (低表达) 
# LY96 : Control mean = 10.26 , VTE mean = 11.26 , log2FC = 0.134 (高表达) 


# ==================== 输出6个核心基因的统计结果文件 ====================

library(broom)

# 定义保存统计结果的函数
save_gene_stats <- function(expr_sub, dataset_name) {
  results <- data.frame()
  for (gene in core_genes) {
    control_vals <- expr_sub[expr_sub$group == "Control", gene]
    vte_vals <- expr_sub[expr_sub$group == "VTE", gene]
    # 计算统计量
    control_mean <- mean(control_vals)
    control_sd <- sd(control_vals)
    vte_mean <- mean(vte_vals)
    vte_sd <- sd(vte_vals)
    log2fc <- log2(vte_mean / control_mean)
    # Wilcoxon检验
    test_res <- wilcox.test(vte_vals, control_vals)
    p_val <- test_res$p.value
    trend <- ifelse(vte_mean > control_mean, "高表达", "低表达")
    results <- rbind(results, data.frame(
      Dataset = dataset_name,
      Gene = gene,
      Control_Mean = round(control_mean, 4),
      Control_SD = round(control_sd, 4),
      VTE_Mean = round(vte_mean, 4),
      VTE_SD = round(vte_sd, 4),
      log2FC = round(log2fc, 4),
      P_value = format(p_val, scientific = TRUE, digits = 3),
      Trend = trend
    ))
  }
  return(results)
}

# 生成两个数据集的统计结果
stats_19151 <- save_gene_stats(expr_sub_19151, "GSE19151")
stats_48000 <- save_gene_stats(expr_sub_48000, "GSE48000")

# 合并并保存
all_stats <- rbind(stats_19151, stats_48000)
write.csv(all_stats, "core_genes_expression_stats.csv", row.names = FALSE)

# 同时输出为Excel文件（需安装openxlsx包）
if (require(openxlsx, quietly = TRUE)) {
  write.xlsx(all_stats, "core_genes_expression_stats.xlsx", rowNames = FALSE)
}

cat("\n统计结果已保存至 core_genes_expression_stats.csv\n")
