#===================== GO-KEGG 富集分析 ===========================
rm(list = ls())
setwd("/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3")
if (!dir.exists("go_kegg")) dir.create("go_kegg")
setwd("go_kegg")

library(clusterProfiler)
library(org.Hs.eg.db)
library(ggplot2)
library(dplyr)
library(writexl)
library(stringr)
library(ggprism)

candidate <- read.csv("../Venn/Common_DEGs.csv")$Gene

s2e <- bitr(candidate, 
            fromType = "SYMBOL", 
            toType = "ENTREZID", 
            OrgDb = "org.Hs.eg.db")
s2e <- distinct(s2e, SYMBOL, .keep_all = T)

enrich_go <- enrichGO(gene = s2e$ENTREZID,
                      OrgDb = org.Hs.eg.db,
                      keyType = "ENTREZID",
                      ont = "ALL",
                      pAdjustMethod = "BH",
                      pvalueCutoff = 0.05,
                      qvalueCutoff = 0.2,
                      readable = TRUE)

GO_ALL <- enrich_go@result
BP <- GO_ALL[GO_ALL$ONTOLOGY == 'BP', ] %>% arrange(pvalue, desc(Count))
CC <- GO_ALL[GO_ALL$ONTOLOGY == 'CC', ] %>% arrange(pvalue, desc(Count))
MF <- GO_ALL[GO_ALL$ONTOLOGY == 'MF', ] %>% arrange(pvalue, desc(Count))

kk <- enrichKEGG(gene = s2e$ENTREZID,
                 organism = "hsa",
                 keyType = "kegg",
                 pAdjustMethod = "BH",
                 pvalueCutoff = 0.05,
                 qvalueCutoff = 0.2)

kk <- setReadable(kk, OrgDb = org.Hs.eg.db, keyType = "ENTREZID")
KEGG_result <- kk@result %>% arrange(pvalue, desc(Count))

write_xlsx(GO_ALL, "GO_enrichment.xlsx")
write_xlsx(KEGG_result, "KEGG_enrichment.xlsx")

use_pathway <- bind_rows(
  GO_ALL %>%
    filter(ONTOLOGY %in% c("BP", "CC", "MF")) %>%
    group_by(ONTOLOGY) %>%
    arrange(pvalue, desc(Count)) %>%
    slice_head(n = 5) %>%
    ungroup(),
  KEGG_result %>%
    slice_head(n = 5) %>%
    mutate(ONTOLOGY = 'KEGG')) %>%
  mutate(ONTOLOGY = factor(ONTOLOGY, 
                           levels = rev(c('BP', 'CC', 'MF', 'KEGG')))) %>%
  arrange(ONTOLOGY, pvalue) %>%
  mutate(Description = forcats::fct_inorder(Description)) %>%
  tibble::rowid_to_column('index')

use_pathway <- use_pathway %>%
  mutate(geneID = sapply(str_split(geneID, "/"), 
                         function(x) paste(head(x, 20), collapse = "/")))

width <- 0.5
xaxis_max <- max(-log10(use_pathway$pvalue), na.rm = TRUE) + 1

ontology_table <- table(use_pathway$ONTOLOGY)
ontology_df <- as.data.frame(ontology_table)
colnames(ontology_df) <- c("ONTOLOGY", "n")
ontology_df$ymax <- cumsum(ontology_df$n)
ontology_df$ymin <- c(0, head(ontology_df$ymax, -1)) + 0.6
ontology_df$ymax <- ontology_df$ymax + 0.4
ontology_df$xmin <- -3 * width
ontology_df$xmax <- -2 * width

plot_enrichment <- function() {
  p <- use_pathway %>%
    ggplot(aes(-log10(pvalue), y = index, fill = ONTOLOGY)) +
    geom_col(aes(y = Description), width = 0.6, alpha = 0.8) +
    geom_text(aes(x = 0.05, label = Description), hjust = 0, size = 5) +
    geom_text(aes(x = 0.1, label = geneID, colour = ONTOLOGY),
              hjust = 0, vjust = 2.6, size = 3.5, fontface = 'italic',
              show.legend = FALSE) +
    geom_point(aes(x = -width, size = Count), shape = 21) +
    geom_text(aes(x = -width, label = Count), size = 3) +
    scale_size_continuous(name = 'Count', range = c(5, 12)) +
    geom_rect(aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax,
                  fill = ONTOLOGY),
              data = ontology_df, inherit.aes = FALSE) +
    geom_text(aes(x = (xmin + xmax) / 2, 
                  y = (ymin + ymax) / 2, label = ONTOLOGY),
              data = ontology_df, inherit.aes = FALSE, angle = 90,
              hjust = 0.5, vjust = 0.5, size = 4) +
    annotate("segment", x = 0, y = 0, 
             xend = xaxis_max, yend = 0, linewidth = 1.5) +
    labs(y = NULL) +
    scale_fill_manual(name = 'Category',
                      breaks = c('BP', 'CC', 'MF', 'KEGG'),
                      values = c(BP = "#eaa052", CC = "#b74147", 
                                 MF = "#90ad5b", KEGG = "#23929c")) +
    scale_colour_manual(breaks = c('BP', 'CC', 'MF', 'KEGG'), 
                        values = c(BP = "#eaa052", CC = "#b74147", 
                                   MF = "#90ad5b", KEGG = "#23929c")) +
    scale_x_continuous(breaks = seq(0, xaxis_max, 2), 
                       expand = expansion(c(0, 0))) +
    theme_prism() +
    theme(axis.text.y = element_blank(),
          axis.line = element_blank(),
          axis.ticks.y = element_blank(),
          legend.title = element_text(),
          legend.position = "right",
          legend.direction = "vertical")
  return(p)
}

enrichment_plot <- plot_enrichment()

width_p <- length(use_pathway$ONTOLOGY) / 4 * 3
height_p <- length(use_pathway$ONTOLOGY) / 20 * 9

ggsave("GO_KEGG_bar.pdf", width = width_p, height = height_p, 
       enrichment_plot, family = "Times", limitsize = FALSE)
ggsave("GO_KEGG_bar.png", width = width_p, height = height_p, 
       enrichment_plot, limitsize = FALSE)

# 打印用于绘图的前5条通路名称
cat(paste(BP$Description[1:5], collapse = "\n"), "\n")
cat(paste(CC$Description[1:5], collapse = "\n"), "\n")
cat(paste(MF$Description[1:5], collapse = "\n"), "\n")
cat(paste(KEGG_result$Description[1:5], collapse = "\n"), "\n")

#==========================================================================
