
rm(list = ls())
setwd("/data/nas3/refinement6/projects/Apr/02-KYGW-10245-3")

if (!dir.exists("nomogram_new")) dir.create("nomogram_new")
setwd("nomogram_new")

library(tidyverse)
library(rms)
library(pROC)
library(ggplot2)
library(rmda)
library(patchwork)

calc_auc_pvalue <- function(roc_obj) {
  ci_val <- ci(roc_obj, method = "delong")
  auc_est <- as.numeric(roc_obj$auc)
  se <- (ci_val[3] - ci_val[1]) / (2 * 1.96)
  z <- (auc_est - 0.5) / se
  p_val <- 2 * pnorm(-abs(z))
  return(p_val)
}

# 计算单个基因的性能指标
calc_single_gene_perf <- function(gene, data, group_col) {
  # 提取表达值和真实标签（转换为数值：VTE=1, Control=0）
  exp_val <- data[[gene]]
  actual_raw <- data[[group_col]]
  actual <- ifelse(as.character(actual_raw) == "VTE", 1, 0)
  
  # 计算ROC（正类=1）
  roc_obj <- roc(actual, exp_val, levels = c(0, 1), direction = "<")
  auc_val <- as.numeric(roc_obj$auc)
  
  # 若AUC<0.5，则反转表达值方向（使AUC>0.5，保证阈值有效）
  if (auc_val < 0.5) {
    exp_val <- -exp_val
    roc_obj <- roc(actual, exp_val, levels = c(0, 1), direction = "<")
    auc_val <- as.numeric(roc_obj$auc)
  }
  
  # AUC置信区间和P值
  ci_auc <- ci(roc_obj, method = "delong")
  p_auc <- calc_auc_pvalue(roc_obj)
  
  # 最佳阈值（Youden指数最大）
  best_coords <- coords(roc_obj, "best", ret = "all", transpose = FALSE)
  # 防止返回多行（某些pROC版本可能返回两行），只取第一行
  if (is.data.frame(best_coords) && nrow(best_coords) > 1) {
    best_coords <- best_coords[1, ]
  }
  best_thres <- best_coords$threshold
  sensitivity <- best_coords$sensitivity
  specificity <- best_coords$specificity
  
  # 处理极端阈值（Inf, -Inf, NA）——用中位数替代
  if (is.na(best_thres) || !is.finite(best_thres)) {
    best_thres <- median(exp_val)
    predicted_tmp <- ifelse(exp_val >= best_thres, 1, 0)
    tp_tmp <- sum(predicted_tmp == 1 & actual == 1)
    tn_tmp <- sum(predicted_tmp == 0 & actual == 0)
    fp_tmp <- sum(predicted_tmp == 1 & actual == 0)
    fn_tmp <- sum(predicted_tmp == 0 & actual == 1)
    sensitivity <- ifelse((tp_tmp+fn_tmp)>0, tp_tmp/(tp_tmp+fn_tmp), NA)
    specificity <- ifelse((tn_tmp+fp_tmp)>0, tn_tmp/(tn_tmp+fp_tmp), NA)
  }
  
  # 根据最佳阈值进行二分类预测
  predicted <- ifelse(exp_val >= best_thres, 1, 0)
  
  # 计算混淆矩阵
  tp <- sum(predicted == 1 & actual == 1)
  tn <- sum(predicted == 0 & actual == 0)
  fp <- sum(predicted == 1 & actual == 0)
  fn <- sum(predicted == 0 & actual == 1)
  
  ppv <- ifelse((tp + fp) > 0, tp / (tp + fp), NA)
  npv <- ifelse((tn + fn) > 0, tn / (tn + fn), NA)
  youden <- sensitivity + specificity - 1
  
  res <- data.frame(
    Model = paste0("Single_", gene),
    AUC = round(auc_val, 3),
    AUC_CI_lower = round(ci_auc[1], 3),
    AUC_CI_upper = round(ci_auc[3], 3),
    P_value_AUC = format(p_auc, scientific = TRUE, digits = 3),
    Best_Threshold = round(best_thres, 4),
    Sensitivity = round(sensitivity, 3),
    Specificity = round(specificity, 3),
    PPV = round(ppv, 3),
    NPV = round(npv, 3),
    Youden_Index = round(youden, 3)
  )
  return(list(roc_obj = roc_obj, performance = res))
}

# 计算整体模型性能（含约登指数）
overall_perf_from_model <- function(model, data, group_col) {
  pred_prob <- predict(model, newdata = data, type = "fitted")
  actual_raw <- data[[group_col]]
  actual <- ifelse(as.character(actual_raw) == "VTE", 1, 0)
  
  roc_obj <- roc(actual, pred_prob, levels = c(0, 1), direction = "<")
  auc_val <- auc(roc_obj)
  ci_auc <- ci(roc_obj, method = "delong")
  p_auc <- calc_auc_pvalue(roc_obj)
  
  best_coords <- coords(roc_obj, "best", ret = "all", transpose = FALSE)
  if (is.data.frame(best_coords) && nrow(best_coords) > 1) {
    best_coords <- best_coords[1, ]
  }
  best_thres <- best_coords$threshold
  sensitivity <- best_coords$sensitivity
  specificity <- best_coords$specificity
  
  # 处理极端阈值
  if (is.na(best_thres) || !is.finite(best_thres)) {
    best_thres <- median(pred_prob)
    predicted_tmp <- ifelse(pred_prob >= best_thres, 1, 0)
    tp_tmp <- sum(predicted_tmp == 1 & actual == 1)
    tn_tmp <- sum(predicted_tmp == 0 & actual == 0)
    fp_tmp <- sum(predicted_tmp == 1 & actual == 0)
    fn_tmp <- sum(predicted_tmp == 0 & actual == 1)
    sensitivity <- ifelse((tp_tmp+fn_tmp)>0, tp_tmp/(tp_tmp+fn_tmp), NA)
    specificity <- ifelse((tn_tmp+fp_tmp)>0, tn_tmp/(tn_tmp+fp_tmp), NA)
  }
  
  predicted <- ifelse(pred_prob >= best_thres, 1, 0)
  tp <- sum(predicted == 1 & actual == 1)
  tn <- sum(predicted == 0 & actual == 0)
  fp <- sum(predicted == 1 & actual == 0)
  fn <- sum(predicted == 0 & actual == 1)
  
  ppv <- ifelse((tp + fp) > 0, tp / (tp + fp), NA)
  npv <- ifelse((tn + fn) > 0, tn / (tn + fn), NA)
  youden <- sensitivity + specificity - 1
  
  res <- data.frame(
    Model = "Overall_4genes",
    AUC = round(auc_val, 3),
    AUC_CI_lower = round(ci_auc[1], 3),
    AUC_CI_upper = round(ci_auc[3], 3),
    P_value_AUC = format(p_auc, scientific = TRUE, digits = 3),
    Best_Threshold = round(best_thres, 4),
    Sensitivity = round(sensitivity, 3),
    Specificity = round(specificity, 3),
    PPV = round(ppv, 3),
    NPV = round(npv, 3),
    Youden_Index = round(youden, 3)
  )
  return(list(roc_obj = roc_obj, performance = res))
}

# ==================== 1. 读取核心基因 ====================
core_genes <- c("BFAR", "CXorf21", "PIP5K1A", "UBFD1")
cat("核心基因：", paste(core_genes, collapse = ", "), "\n")

# ==================== 2. 读取训练数据 ====================
train_expr <- read.csv("../data/expression_GSE19151.csv", row.names = 1, check.names = FALSE)
train_group <- read.csv("../data/group_GSE19151.csv", check.names = FALSE)

# ==================== 3. 准备训练数据 ====================
missing_genes <- core_genes[!core_genes %in% rownames(train_expr)]
if (length(missing_genes) > 0) {
  stop("以下核心基因不在表达矩阵中：", paste(missing_genes, collapse = ", "))
}
train_data <- train_expr[rownames(train_expr) %in% core_genes, ] %>% t() %>% as.data.frame()
train_data <- train_data[rownames(train_data) %in% train_group$sample, ]
train_data$group <- factor(train_group$group[match(rownames(train_data), train_group$sample)], 
                           levels = c("Control", "VTE"))

# ==================== 4. 构建模型 ====================
ddist <- datadist(train_data)
options(datadist = "ddist")
model <- lrm(group ~ ., data = train_data, x = TRUE, y = TRUE)
write.csv(model$coefficients, "01_model_coefficients.csv", row.names = TRUE)

# ==================== 5. 列线图 ====================
pdf("02_nomogram.pdf", width = 10, height = 8)
nom <- nomogram(model, fun = plogis, funlabel = "Risk of VTE", 
                fun.at = c(0.1, 0.3, 0.5, 0.7, 0.9), lp = TRUE)
plot(nom, cex.axis = 0.8, cex.var = 0.9)
dev.off()
png("02_nomogram.png", width = 10, height = 8, units = "in", res = 600)
plot(nom, cex.axis = 0.8, cex.var = 0.9)
dev.off()

# ==================== 6. 整体模型 ROC 曲线 ====================
train_pred <- predict(model, newdata = train_data, type = "fitted")
train_roc <- roc(ifelse(train_data$group == "VTE", 1, 0), train_pred, levels = c(0,1), direction = "<")
train_auc <- round(auc(train_roc), 3)
pdf("03_ROC_curve.pdf", width = 6, height = 5)
plot(train_roc, col = "#FF7F00", lwd = 2, main = "ROC Curve")
legend("bottomright", legend = paste("AUC =", train_auc), col = "#FF7F00", lwd = 2, bty = "n")
dev.off()
png("03_ROC_curve.png", width = 6, height = 5, units = "in", res = 600)
plot(train_roc, col = "#FF7F00", lwd = 2, main = "ROC Curve")
legend("bottomright", legend = paste("AUC =", train_auc), col = "#FF7F00", lwd = 2, bty = "n")
dev.off()

# ==================== 7. 校准曲线 ====================
pdf("04_calibration.pdf", width = 6, height = 6)
cal <- calibrate(model, method = "boot", B = 200)
plot(cal, xlab = "Predicted Probability", ylab = "Observed Probability", main = "Calibration Curve")
dev.off()
png("04_calibration.png", width = 6, height = 6, units = "in", res = 600)
plot(cal, xlab = "Predicted Probability", ylab = "Observed Probability", main = "Calibration Curve")
dev.off()

# ==================== 8. 决策曲线分析 ====================
train_dca <- train_data
train_dca$group <- as.numeric(train_dca$group) - 1  
colnames(train_dca) <- make.names(colnames(train_dca))
gene_names <- colnames(train_dca)[colnames(train_dca) != "group"]
formula_str <- paste("group ~", paste(gene_names, collapse = " + "))
formula <- as.formula(formula_str)
train_decision <- decision_curve(formula, data = train_dca, family = binomial(link = "logit"),
                                 thresholds = seq(0, 1, by = 0.01), confidence.intervals = 0.95)
pdf("05_decision_curve.pdf", width = 6, height = 5)
plot_decision_curve(list(train_decision), curve.names = c("Model"), col = c("#FF7F00"), lwd = 2,
                    legend.position = "bottomright")
dev.off()
png("05_decision_curve.png", width = 6, height = 5, units = "in", res = 600)
plot_decision_curve(list(train_decision), curve.names = c("Model"), col = c("#FF7F00"), lwd = 2,
                    legend.position = "bottomright")
dev.off()

# ==================== 9. 补充分析（单基因ROC图 + 完整性能指标输出） ====================
if (!dir.exists("single_gene_roc")) dir.create("single_gene_roc")

# 计算整体模型性能（包含所有指标）
overall_res <- overall_perf_from_model(model, train_data, "group")
overall_stats <- overall_res$performance
write.csv(overall_stats, "overall_model_metrics.csv", row.names = FALSE)
cat("\n=== 整体模型性能 ===\n")
print(overall_stats)

# 计算单个基因完整性能
single_results <- list()
single_stats <- data.frame()
for (g in core_genes) {
  tmp <- calc_single_gene_perf(g, train_data, "group")
  single_results[[g]] <- tmp$roc_obj
  single_stats <- rbind(single_stats, tmp$performance)
}
write.csv(single_stats, "single_gene_metrics.csv", row.names = FALSE)
cat("\n=== 单基因完整性能（含阈值、灵敏度、特异度、PPV、NPV、约登指数） ===\n")
print(single_stats)

# 绘制四个基因的 ROC 曲线组合图
roc_plots <- list()
for (i in seq_along(core_genes)) {
  g <- core_genes[i]
  roc_obj <- single_results[[g]]
  auc_val <- single_stats$AUC[single_stats$Model == paste0("Single_", g)]
  df_roc <- data.frame(fpr = 1 - roc_obj$specificities, tpr = roc_obj$sensitivities)
  p <- ggplot(df_roc, aes(x = fpr, y = tpr)) +
    geom_line(color = "#FF7F00", size = 1.2) +
    geom_abline(linetype = "dashed", color = "grey50") +
    labs(title = g, subtitle = paste("AUC =", auc_val), 
         x = "1 - Specificity", y = "Sensitivity") +
    theme_bw(base_size = 11) +
    theme(plot.title = element_text(hjust = 0.5, face = "bold"),
          plot.subtitle = element_text(hjust = 0.5))
  roc_plots[[i]] <- p
}
combined_roc <- (roc_plots[[1]] | roc_plots[[2]]) / (roc_plots[[3]] | roc_plots[[4]])
ggsave("single_gene_roc/combined_single_gene_ROC.pdf", plot = combined_roc, width = 8, height = 7)
ggsave("single_gene_roc/combined_single_gene_ROC.png", plot = combined_roc, width = 8, height = 7, dpi = 600)

# 单独保存每个 ROC 图片
for (i in seq_along(core_genes)) {
  g <- core_genes[i]
  p_single <- roc_plots[[i]]
  ggsave(paste0("single_gene_roc/ROC_", g, ".pdf"), plot = p_single, width = 4, height = 4)
  ggsave(paste0("single_gene_roc/ROC_", g, ".png"), plot = p_single, width = 4, height = 4, dpi = 600)
}

